import React from "react";
import { connect } from "frontity";
import {} from "./styles";

const NameComponent = () => {
  return <></>;
};

export default connect(NameComponent);
