import React from "react";
import { connect } from "frontity";

const Post = () => {
  return (
    <>
      <p>Componente Post</p>
    </>
  );
};
export default connect(Post);
